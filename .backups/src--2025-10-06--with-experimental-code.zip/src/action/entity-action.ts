import { type Abortable } from '@xstd/abortable';

// export type EntityActionArguments<GArguments extends readonly any[]> =
//   [...GArguments] extends readonly [...args: infer GArgs, last?: infer GLast] ?
//     GLast extends Abortable ?
//       GArguments
//     : [...args: GArgs, options?: Abortable]
//   : never;
//
// export interface EntityActionWithCustomAbortable<
//   GArguments extends EntityActionArguments<GArguments>,
//   GReturn,
// > {
//   (...args: GArguments): Promise<GReturn>;
// }

export interface EntityAction<
  GArguments extends readonly any[],
  GReturn,
  GAbortable extends Abortable = Abortable,
> {
  (...args: [...GArguments, options?: GAbortable]): Promise<GReturn>;
}

export type EntityActionMap = {
  readonly [key: string]: EntityAction<any, any>;
};
