import { type Abortable } from '@xstd/abortable';
import { type PushToPullOptions, ReadableFlow, ReadableFlowContext } from '@xstd/flow';
import { type EntityProperty } from './entity-property.js';

export const DEFAULT_ENTITY_PROPERTY: EntityProperty<any> = Object.freeze({
  get: async ({ signal }: Abortable = {}): Promise<unknown> => {
    signal?.throwIfAborted();
    throw new Error('Property is not readable.');
  },
  set: async (_value: unknown, { signal }: Abortable = {}): Promise<void> => {
    signal?.throwIfAborted();
    throw new Error('Property is not writable.');
  },
  observer: new ReadableFlow<unknown, [options?: PushToPullOptions]>(async function* ({
    signal,
  }: ReadableFlowContext): AsyncGenerator<unknown, void, unknown> {
    signal.throwIfAborted();
    throw new Error('Property is not observable.');
  }),
});
