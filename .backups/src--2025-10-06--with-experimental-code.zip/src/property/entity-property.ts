import { type Abortable } from '@xstd/abortable';
import { type PushToPullOptions, ReadableFlow } from '@xstd/flow';

export interface EntityProperty<GValue> {
  readonly get: EntityPropertyGet<GValue>;
  readonly set: EntityPropertySet<GValue>;
  readonly observer: EntityPropertyObserver<GValue>;
}

export interface EntityPropertyGet<GValue> {
  (options?: Abortable): Promise<GValue>;
}

export interface EntityPropertySet<GValue> {
  (value: GValue, options?: Abortable): Promise<void>;
}

export type EntityPropertyObserver<GValue> = ReadableFlow<GValue, [options?: PushToPullOptions]>;

export type EntityPropertyMap = {
  readonly [key: string]: EntityProperty<any>;
};

/*--------*/

// export interface EntityPropertyExtended<GValue> extends EntityProperty<GValue> {
//   readonly description: string;
// }

// export class EntityPropertyImpl<GValue> implements EntityProperty<GValue> {
//   readonly #unit: EntityPropertyGet<GValue>;
//   readonly #get: EntityPropertyGet<GValue>;
//   readonly #set: EntityPropertySet<GValue>;
//   readonly #observer: EntityPropertyObserver<GValue>;
//
//   constructor(
//     {
//       get,
//       set,
//       observer,
//     }: EntityProperty<GValue>
//   ) {
//     this.#get = get;
//     this.#set = set;
//     this.#observer = observer;
//   }
//
//   get get(): EntityPropertyGet<GValue> {
//     return this.#get;
//   }
//
//   get set(): EntityPropertySet<GValue> {
//     return this.#set;
//   }
//
//   get observer(): EntityPropertyObserver<GValue> {
//     return this.#observer;
//   }
//
//
// }
