import { type Abortable } from '@xstd/abortable';
import { type BidirectionalMapFunctions } from '@xstd/functional';
import { type EntityProperty } from '../../entity-property.js';

export function mapEntityProperty<GIn, GOut>(
  property: EntityProperty<GIn>,
  { inOut, outIn }: BidirectionalMapFunctions<GIn, GOut>,
): EntityProperty<GOut> {
  return {
    get: async (options?: Abortable): Promise<GOut> => {
      return inOut(await property.get(options));
    },
    set: async (value: GOut, options?: Abortable): Promise<void> => {
      return await property.set(outIn(value), options);
    },
    observer: property.observer.map(inOut),
  };
}
