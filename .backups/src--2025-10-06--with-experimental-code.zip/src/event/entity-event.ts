import { type PushToPullOptions, type ReadableFlow } from '@xstd/flow';

export type EntityEvent<GValue> = ReadableFlow<GValue, [options?: PushToPullOptions]>;

export type EntityEventMap = {
  readonly [key: string]: EntityEvent<any>;
};
