import { Action } from '@xstd/action';
import { type SetEntityPropertyValueAction } from '../set-entity-property-value.action.js';

/**
 * The default `SetEntityPropertyValueAction`.
 *
 * When invoked, it throws an error stating that the property is not writable.
 */
export const DEFAULT_SET_ENTITY_PROPERTY_VALUE_ACTION: SetEntityPropertyValueAction<any> =
  new Action<[value: unknown], void>(async (signal: AbortSignal): Promise<void> => {
    signal.throwIfAborted();
    throw new Error('Property is not writable.');
  });
