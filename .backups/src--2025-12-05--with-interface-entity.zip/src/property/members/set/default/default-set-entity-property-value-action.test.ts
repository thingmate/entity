import { NEVER_ABORTED } from '@xstd/abortable';
import { describe, expect, it } from 'vitest';
import { DEFAULT_SET_ENTITY_PROPERTY_VALUE_ACTION } from './default-set-entity-property-value-action.js';

describe('DEFAULT_SET_ENTITY_PROPERTY_VALUE_ACTION', () => {
  it('should reject', async () => {
    await expect(
      DEFAULT_SET_ENTITY_PROPERTY_VALUE_ACTION.invoke(NEVER_ABORTED, null),
    ).rejects.toThrow();
  });
});
