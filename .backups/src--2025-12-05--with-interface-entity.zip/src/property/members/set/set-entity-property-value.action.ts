import { type Action } from '@xstd/action';

/**
 * An `Action` used to _write_ the value of an entity property.
 *
 * @template GValue - The type of the value being written.
 */
export type SetEntityPropertyValueAction<GValue> = Action<[value: GValue], void>;
