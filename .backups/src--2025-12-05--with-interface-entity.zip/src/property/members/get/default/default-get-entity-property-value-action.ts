import { Action } from '@xstd/action';
import { type GetEntityPropertyValueAction } from '../get-entity-property-value.action.js';

/**
 * The default `GetEntityPropertyValueAction`.
 *
 * When invoked, it throws an error stating that the property is not readable.
 */
export const DEFAULT_GET_ENTITY_PROPERTY_VALUE_ACTION: GetEntityPropertyValueAction<any> =
  new Action<[], unknown>(async (signal: AbortSignal): Promise<unknown> => {
    signal.throwIfAborted();
    throw new Error('Property is not readable.');
  });
