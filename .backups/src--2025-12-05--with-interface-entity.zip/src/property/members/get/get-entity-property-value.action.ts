import { type Action } from '@xstd/action';

/**
 * An `Action` used to _read_ the value of an entity property.
 *
 * @template GValue - The type of the value being read.
 */
export type GetEntityPropertyValueAction<GValue> = Action<[], GValue>;
