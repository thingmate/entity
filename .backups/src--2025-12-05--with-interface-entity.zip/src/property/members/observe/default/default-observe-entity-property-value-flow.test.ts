import { NEVER_ABORTED } from '@xstd/abortable';
import { describe, expect, it } from 'vitest';
import { DEFAULT_OBSERVE_ENTITY_PROPERTY_VALUE_FLOW } from './default-observe-entity-property-value-flow.js';

describe('DEFAULT_OBSERVE_ENTITY_PROPERTY_VALUE_FLOW', () => {
  it('should reject', async () => {
    await expect(
      DEFAULT_OBSERVE_ENTITY_PROPERTY_VALUE_FLOW.open(NEVER_ABORTED).next(),
    ).rejects.toThrow();
  });
});
