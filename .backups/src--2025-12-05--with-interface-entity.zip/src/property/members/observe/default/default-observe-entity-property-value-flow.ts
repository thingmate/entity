import { Flow, type FlowContext, type FlowIterator } from '@xstd/flow';
import { type ObserveEntityPropertyValueFlow } from '../observe-entity-property-value.flow.js';

/**
 * The default `ObserveEntityPropertyValueFlow`.
 *
 * When invoked, it throws an error stating that the property is not observable.
 */
export const DEFAULT_OBSERVE_ENTITY_PROPERTY_VALUE_FLOW: ObserveEntityPropertyValueFlow<any> =
  new Flow<unknown>(async function* ({ signal }: FlowContext): FlowIterator<any> {
    signal.throwIfAborted();
    throw new Error('Property is not observable.');
  });
