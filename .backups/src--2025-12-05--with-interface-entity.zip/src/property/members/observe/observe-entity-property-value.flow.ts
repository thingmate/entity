import { type Flow, type PushToPullOptions } from '@xstd/flow';

/**
 * A `Flow` used to _observe_ the value of an entity property.
 *
 * @template GValue - The type of the value being observed.
 */
export type ObserveEntityPropertyValueFlow<GValue> = Flow<GValue, [options?: PushToPullOptions]>;
