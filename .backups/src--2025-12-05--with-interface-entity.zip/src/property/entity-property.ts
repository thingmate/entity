import { type GetEntityPropertyValueAction } from './members/get/get-entity-property-value.action.js';
import { type ObserveEntityPropertyValueFlow } from './members/observe/observe-entity-property-value.flow.js';
import { type SetEntityPropertyValueAction } from './members/set/set-entity-property-value.action.js';

/**
 * Represents an _abstract_ `property`: a **value** that can be read, written, or observed.
 *
 * @template GValue The type of the property value.
 */
export class EntityProperty<GValue> {
  readonly get: GetEntityPropertyValueAction<GValue>;
  readonly set: SetEntityPropertyValueAction<GValue>;
  readonly observe: ObserveEntityPropertyValueFlow<GValue>;
}

/**
 * Represents a _named_ collection of `EntityProperty`s.
 */
export type EntityPropertyMap = {
  readonly [key: string]: EntityProperty<any>;
};

export const enum EntityPropertyMode {
  READ = 1 /* 1 << 0 */,
  WRITE = 2 /* 1 << 1 */,
  OBSERVE = 4 /* 1 << 2 */,
}
