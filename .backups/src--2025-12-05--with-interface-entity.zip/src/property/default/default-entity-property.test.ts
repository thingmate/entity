import { NEVER_ABORTED } from '@xstd/abortable';
import { describe, expect, test } from 'vitest';
import { DEFAULT_ENTITY_PROPERTY } from './default-entity-property.js';

describe('DEFAULT_ENTITY_PROPERTY', () => {
  test('get should reject', async () => {
    await expect(DEFAULT_ENTITY_PROPERTY.get.invoke()).rejects.toThrow();
  });

  test('set should reject', async () => {
    await expect(DEFAULT_ENTITY_PROPERTY.set.invoke(1)).rejects.toThrow();
  });

  test('observe should reject', async () => {
    await expect(DEFAULT_ENTITY_PROPERTY.observe.open(NEVER_ABORTED).next()).rejects.toThrow();
  });
});
