import { type Action } from '@xstd/action';

/**
 * Represents an abstract `event`: an action observing the _next_ incoming value.
 *
 * @template GValue - The type of the value associated with the entity event.
 */
export type EntityEvent<GEvent> = Action<[], GEvent>;

/**
 * Represents a _named_ collection of `EntityEvent`s.
 */
export type EntityEventMap = {
  readonly [key: string]: EntityEvent<any>;
};
