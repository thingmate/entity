import { type Abortable } from '@xstd/abortable';
import { type Action } from '@xstd/action';

/**
 * Represents a function to _read_ a value.
 *
 * @template GValue - The type of the value being read.
 * @returns {Promise<GValue>} A promise that resolves with the read value.
 */
export type GetEntityValue<GValue> = Action<[], GValue, GetEntityValueOptions>;

/**
 * Represents the optional options to provide to `GetEntityValue`.
 */
export interface GetEntityValueOptions extends Abortable {
  /**
   * The `stage` property is an optional value that determines how the value is fetched:
   *
   * - `current` (default): The function returns the current value through a "pull" mechanism.
   * - `next`: The function returns the next value, awaiting until a new value is available (it awaits for a future value).
   */
  readonly stage?: GetEntityValueStage;
}

export type GetEntityValueStage = 'current' | 'next';
