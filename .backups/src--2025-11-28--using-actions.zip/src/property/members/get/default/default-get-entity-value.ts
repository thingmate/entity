import { Action } from '@xstd/action';
import { type GetEntityValue, type GetEntityValueOptions } from '../get-entity-value.js';

/**
 * A default action for `GetEntityValue`.
 *
 * When invoked, it throws an error stating that the property is not readable.
 */
export const DEFAULT_GET_ENTITY_VALUE: GetEntityValue<any> = new Action<
  [],
  unknown,
  GetEntityValueOptions
>(async ({ signal }: GetEntityValueOptions = {}): Promise<unknown> => {
  signal?.throwIfAborted();
  throw new Error('Property is not readable.');
});
