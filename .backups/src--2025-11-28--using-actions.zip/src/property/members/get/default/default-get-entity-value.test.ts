import { describe, expect, it } from 'vitest';
import { DEFAULT_GET_ENTITY_VALUE } from './default-get-entity-value.js';

describe('DEFAULT_GET_ENTITY_VALUE', () => {
  it('should reject', async () => {
    await expect(DEFAULT_GET_ENTITY_VALUE.invoke()).rejects.toThrow();
  });
});
