import { Action } from '@xstd/action';
import { type GetEntityValue, type GetEntityValueOptions } from '../../get-entity-value.js';

export interface CreateGetEntityValueActionFromCurrentAndNextActionsOptions<GValue> {
  readonly current: Action<[], GValue>;
  readonly next: Action<[], GValue>;
}

export function createGetEntityValueActionFromCurrentAndNextActions<GValue>({
  current,
  next,
}: CreateGetEntityValueActionFromCurrentAndNextActionsOptions<GValue>): GetEntityValue<GValue> {
  return new Action<[], GValue, GetEntityValueOptions>(
    ({ stage = 'current', ...options }: GetEntityValueOptions = {}): Promise<GValue> => {
      return stage === 'current' ? current.invoke(options) : next.invoke(options);
    },
  );
}
