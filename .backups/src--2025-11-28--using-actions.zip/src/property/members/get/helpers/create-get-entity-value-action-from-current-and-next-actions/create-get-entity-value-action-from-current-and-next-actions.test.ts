import { Action } from '@xstd/action';
import { describe, expect, it } from 'vitest';
import { createGetEntityValueActionFromCurrentAndNextActions } from './create-get-entity-value-action-from-current-and-next-actions.js';

describe('createGetEntityValueActionFromCurrentAndNextActions', () => {
  it('should return expected values', async () => {
    const action = createGetEntityValueActionFromCurrentAndNextActions({
      current: new Action(async () => {
        return 1;
      }),
      next: new Action(async () => {
        return 2;
      }),
    });

    await expect(action.invoke()).resolves.toBe(1);
    await expect(action.invoke({ stage: 'current' })).resolves.toBe(1);
    await expect(action.invoke({ stage: 'next' })).resolves.toBe(2);
  });
});
