import { type Action } from '@xstd/action';

/**
 * Represents a function to _write_ a value.
 *
 * @template GValue - The type of the value being written.
 * @param {GValue} value - The value to write.
 * @returns {Promise<void>} A promise that resolves once the value has been successfully written
 * or rejects in case of errors.
 */
export type SetEntityValue<GValue> = Action<[value: GValue], void>;
