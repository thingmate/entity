import { describe, expect, it } from 'vitest';
import { DEFAULT_SET_ENTITY_VALUE } from './default-set-entity-value.js';

describe('DEFAULT_SET_ENTITY_VALUE', () => {
  it('should reject', async () => {
    await expect(DEFAULT_SET_ENTITY_VALUE.invoke(null)).rejects.toThrow();
  });
});
