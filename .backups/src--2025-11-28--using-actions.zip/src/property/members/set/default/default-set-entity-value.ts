import { type Abortable } from '@xstd/abortable';
import { Action } from '@xstd/action';
import { type SetEntityValue } from '../set-entity-value.js';

/**
 * A default action for `SetEntityValue`.
 *
 * When invoked, it throws an error stating that the property is not writable.
 */
export const DEFAULT_SET_ENTITY_VALUE: SetEntityValue<any> = new Action<[value: unknown], void>(
  async (_value: unknown, { signal }: Abortable = {}): Promise<void> => {
    signal?.throwIfAborted();
    throw new Error('Property is not writable.');
  },
);
