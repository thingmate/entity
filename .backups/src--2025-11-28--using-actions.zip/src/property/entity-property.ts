import { type GetEntityValue } from './members/get/get-entity-value.js';
import { type SetEntityValue } from './members/set/set-entity-value.js';

/**
 * Represents an _abstract_ `property`: a **value** that can be read or written.
 *
 * @template GValue The type of the property value.
 */
export interface EntityProperty<GValue> {
  readonly get: GetEntityValue<GValue>;
  readonly set: SetEntityValue<GValue>;
}

/**
 * Represents a _named_ collection of `EntityProperty`s.
 */
export type EntityPropertyMap = {
  readonly [key: string]: EntityProperty<any>;
};
