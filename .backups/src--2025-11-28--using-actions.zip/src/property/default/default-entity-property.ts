import { type EntityProperty } from '../entity-property.js';
import { DEFAULT_GET_ENTITY_VALUE } from '../members/get/default/default-get-entity-value.js';
import { DEFAULT_SET_ENTITY_VALUE } from '../members/set/default/default-set-entity-value.js';

/**
 * An object implementing the methods of a _default_ `EntityProperty`.
 *
 * By default, all the methods reject with a "Property is not readable/writable" Error.
 *
 * @example
 *
 * ```ts
 * const temperature = {
 *   ...DEFAULT_ENTITY_PROPERTY,
 *   get: new Action<[], unknown, GetEntityValueOptions>(async ({ signal }: GetEntityValueOptions = {}): Promise<number> => {
 *     return (await (await fetch('https://weather.org/api/temperature', { signal })).json())
 *       .temperature;
 *   }),
 * };
 * ```
 */
export const DEFAULT_ENTITY_PROPERTY: EntityProperty<any> = Object.freeze({
  get: DEFAULT_GET_ENTITY_VALUE,
  set: DEFAULT_SET_ENTITY_VALUE,
});
